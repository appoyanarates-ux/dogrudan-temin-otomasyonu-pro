<?php
/**
 * Doğrudan Temin Otomasyonu Pro - Kullanıcı Hesabı & Bulut Eşitleme API'si (v1.1.0)
 * Konum: https://evrakplus.com/dogrudan-temin/sync-api.php
 */

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Sync-Key, X-Auth-Token');
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Korumalı veri klasörü
$dataDir = __DIR__ . '/dt_sync_storage';
if (!is_dir($dataDir)) {
    @mkdir($dataDir, 0755, true);
}
$htaccessFile = $dataDir . '/.htaccess';
if (!file_exists($htaccessFile)) {
    $htaccessRules = "<IfModule mod_authz_core.c>\n    Require all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n    Order deny,allow\n    Deny from all\n</IfModule>\n";
    @file_put_contents($htaccessFile, $htaccessRules);
}
$indexFile = $dataDir . '/index.html';
if (!file_exists($indexFile)) {
    @file_put_contents($indexFile, "<!DOCTYPE html><html><head><meta charset='utf-8'></head><body>Yetkisiz Erisim</body></html>");
}

$usersDbFile = $dataDir . '/users_registry.json';
if (!file_exists($usersDbFile)) {
    @file_put_contents($usersDbFile, "{}", LOCK_EX);
}

function loadUsersDb($file) {
    if (!file_exists($file)) return [];
    $raw = @file_get_contents($file);
    if (!$raw) return [];
    $decoded = json_decode($raw, true);
    return is_array($decoded) ? $decoded : [];
}

function saveUsersDb($file, $users) {
    $json = json_encode((object)$users, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    return @file_put_contents($file, $json, LOCK_EX) !== false;
}

function safeStrLen($str) {
    return function_exists('mb_strlen') ? mb_strlen($str, 'UTF-8') : strlen($str);
}

function normalizeUsername($u) {
    $trimmed = trim($u);
    return function_exists('mb_strtolower') ? mb_strtolower($trimmed, 'UTF-8') : strtolower($trimmed);
}

function generateSecureToken() {
    if (function_exists('random_bytes')) {
        try {
            return bin2hex(random_bytes(24));
        } catch (Exception $e) {}
    }
    if (function_exists('openssl_random_pseudo_bytes')) {
        return bin2hex(openssl_random_pseudo_bytes(24));
    }
    return hash('sha256', uniqid('dt_', true) . mt_rand());
}

function loadWorkspace($file) {
    if (!file_exists($file)) {
        return [
            'projects' => [],
            'customInstitutions' => [],
            'deletedIds' => [],
            'updatedAt' => null
        ];
    }
    $content = @file_get_contents($file);
    if (!$content) {
        return [
            'projects' => [],
            'customInstitutions' => [],
            'deletedIds' => [],
            'updatedAt' => null
        ];
    }
    $data = json_decode($content, true);
    if (!is_array($data)) {
        return [
            'projects' => [],
            'customInstitutions' => [],
            'deletedIds' => [],
            'updatedAt' => null
        ];
    }
    return [
        'projects' => isset($data['projects']) && is_array($data['projects']) ? $data['projects'] : [],
        'customInstitutions' => isset($data['customInstitutions']) && is_array($data['customInstitutions']) ? $data['customInstitutions'] : [],
        'deletedIds' => isset($data['deletedIds']) && is_array($data['deletedIds']) ? $data['deletedIds'] : [],
        'updatedAt' => isset($data['updatedAt']) ? $data['updatedAt'] : null
    ];
}

function saveWorkspace($file, $workspace) {
    $workspace['updatedAt'] = gmdate('Y-m-d\TH:i:s\Z');
    $json = json_encode($workspace, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    return @file_put_contents($file, $json, LOCK_EX) !== false ? $workspace : false;
}

function performSmartMerge($storageFile, $clientProjects, $clientInstitutions, $clientDeletedIds) {
    $serverWs = loadWorkspace($storageFile);

    $allDeletedIds = array_values(array_unique(array_merge($serverWs['deletedIds'], $clientDeletedIds)));
    $deletedLookup = array_flip($allDeletedIds);

    $projectMap = [];
    foreach ($serverWs['projects'] as $p) {
        if (!isset($p['id'])) continue;
        $pid = $p['id'];
        if (isset($deletedLookup[$pid])) continue;
        $projectMap[$pid] = $p;
    }

    foreach ($clientProjects as $cp) {
        if (!isset($cp['id'])) continue;
        $pid = $cp['id'];
        if (isset($deletedLookup[$pid])) continue;

        if (!isset($projectMap[$pid])) {
            $projectMap[$pid] = $cp;
        } else {
            $serverTime = isset($projectMap[$pid]['lastUpdated']) ? strtotime($projectMap[$pid]['lastUpdated']) : 0;
            $clientTime = isset($cp['lastUpdated']) ? strtotime($cp['lastUpdated']) : 0;
            if ($clientTime >= $serverTime) {
                $projectMap[$pid] = $cp;
            }
        }
    }

    $mergedProjects = array_values($projectMap);
    usort($mergedProjects, function($a, $b) {
        $ta = isset($a['lastUpdated']) ? strtotime($a['lastUpdated']) : 0;
        $tb = isset($b['lastUpdated']) ? strtotime($b['lastUpdated']) : 0;
        return $tb - $ta;
    });

    $instMap = [];
    foreach ($serverWs['customInstitutions'] as $inst) {
        if (isset($inst['id'])) $instMap[$inst['id']] = $inst;
    }
    foreach ($clientInstitutions as $cInst) {
        if (isset($cInst['id'])) $instMap[$cInst['id']] = $cInst;
    }
    $mergedInstitutions = array_values($instMap);

    $newWs = [
        'projects' => $mergedProjects,
        'customInstitutions' => $mergedInstitutions,
        'deletedIds' => array_slice($allDeletedIds, -200),
        'updatedAt' => gmdate('Y-m-d\TH:i:s\Z')
    ];

    return saveWorkspace($storageFile, $newWs);
}

// JSON Gövdesi
$rawInput = file_get_contents('php://input');
$body = [];
if (!empty($rawInput)) {
    $decoded = json_decode($rawInput, true);
    if (is_array($decoded)) {
        $body = $decoded;
    }
}

$action = isset($_GET['action']) ? $_GET['action'] : (isset($body['action']) ? $body['action'] : 'ping');

// 1. KAYIT OL (REGISTER)
if ($action === 'register') {
    $username = isset($body['username']) ? normalizeUsername($body['username']) : '';
    $password = isset($body['password']) ? trim($body['password']) : '';
    $displayName = isset($body['displayName']) ? trim($body['displayName']) : $username;

    if (safeStrLen($username) < 3) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Kullanıcı adı veya e-posta en az 3 karakter olmalıdır.'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    if (safeStrLen($password) < 4) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Şifre en az 4 karakter olmalıdır.'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $users = loadUsersDb($usersDbFile);
    if (isset($users[$username])) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Bu kullanıcı adı / e-posta zaten kayıtlı. Lütfen "Giriş Yap" sekmesini kullanın.'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $workspaceKey = 'user_' . substr(hash('sha256', 'dt_user_' . $username), 0, 32);
    $token = generateSecureToken();

    $users[$username] = [
        'username' => $username,
        'displayName' => $displayName !== '' ? $displayName : $username,
        'passwordHash' => password_hash($password, PASSWORD_DEFAULT),
        'workspaceKey' => $workspaceKey,
        'token' => $token,
        'createdAt' => gmdate('Y-m-d\TH:i:s\Z')
    ];

    if (!saveUsersDb($usersDbFile, $users)) {
        http_response_code(500);
        echo json_encode(['ok' => false, 'error' => 'Kullanıcı veritabanı kaydedilemedi. Lütfen dt_sync_storage klasörüne yazma izni (755) verildiğinden emin olun.'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $storageFile = $dataDir . '/' . $workspaceKey . '.json';
    $clientProjects = isset($body['projects']) && is_array($body['projects']) ? $body['projects'] : [];
    $clientInstitutions = isset($body['customInstitutions']) && is_array($body['customInstitutions']) ? $body['customInstitutions'] : [];
    $clientDeletedIds = isset($body['deletedIds']) && is_array($body['deletedIds']) ? $body['deletedIds'] : [];

    $saved = performSmartMerge($storageFile, $clientProjects, $clientInstitutions, $clientDeletedIds);

    echo json_encode([
        'ok' => true,
        'user' => [
            'username' => $username,
            'displayName' => $users[$username]['displayName'],
            'token' => $token,
            'syncKey' => $workspaceKey
        ],
        'projects' => $saved ? $saved['projects'] : $clientProjects,
        'customInstitutions' => $saved ? $saved['customInstitutions'] : $clientInstitutions,
        'deletedIds' => $saved ? $saved['deletedIds'] : $clientDeletedIds,
        'updatedAt' => $saved ? $saved['updatedAt'] : gmdate('Y-m-d\TH:i:s\Z'),
        'projectCount' => $saved ? count($saved['projects']) : count($clientProjects)
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// 2. GİRİŞ YAP (LOGIN)
if ($action === 'login') {
    $username = isset($body['username']) ? normalizeUsername($body['username']) : '';
    $password = isset($body['password']) ? trim($body['password']) : '';

    $users = loadUsersDb($usersDbFile);
    if (!isset($users[$username])) {
        http_response_code(401);
        echo json_encode(['ok' => false, 'error' => 'Bu kullanıcı adı veya e-posta ile kayıtlı hesap bulunamadı. İlk kez kullanıyorsanız "Kayıt Ol" sekmesinden hesap oluşturun.'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $userRecord = $users[$username];
    if (!password_verify($password, $userRecord['passwordHash'])) {
        http_response_code(401);
        echo json_encode(['ok' => false, 'error' => 'Girdiğiniz şifre hatalı. Lütfen kontrol edip tekrar deneyin.'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $workspaceKey = $userRecord['workspaceKey'];
    $storageFile = $dataDir . '/' . $workspaceKey . '.json';

    $clientProjects = isset($body['projects']) && is_array($body['projects']) ? $body['projects'] : [];
    $clientInstitutions = isset($body['customInstitutions']) && is_array($body['customInstitutions']) ? $body['customInstitutions'] : [];
    $clientDeletedIds = isset($body['deletedIds']) && is_array($body['deletedIds']) ? $body['deletedIds'] : [];

    $saved = performSmartMerge($storageFile, $clientProjects, $clientInstitutions, $clientDeletedIds);

    echo json_encode([
        'ok' => true,
        'user' => [
            'username' => $userRecord['username'],
            'displayName' => $userRecord['displayName'],
            'token' => $userRecord['token'],
            'syncKey' => $workspaceKey
        ],
        'projects' => $saved ? $saved['projects'] : $clientProjects,
        'customInstitutions' => $saved ? $saved['customInstitutions'] : $clientInstitutions,
        'deletedIds' => $saved ? $saved['deletedIds'] : $clientDeletedIds,
        'updatedAt' => $saved ? $saved['updatedAt'] : gmdate('Y-m-d\TH:i:s\Z'),
        'projectCount' => $saved ? count($saved['projects']) : count($clientProjects)
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// 3. STANDART WORKSPACE İŞLEMLERİ (syncKey veya Kullanıcı workspaceKey ile)
$syncKey = isset($_SERVER['HTTP_X_SYNC_KEY']) ? $_SERVER['HTTP_X_SYNC_KEY'] : (isset($_GET['key']) ? $_GET['key'] : (isset($body['syncKey']) ? $body['syncKey'] : 'varsayilan-kurum'));
$syncKey = trim($syncKey);
if ($syncKey === '') {
    $syncKey = 'varsayilan-kurum';
}

if (strpos($syncKey, 'user_') === 0 && preg_match('/^user_[a-f0-9]{32}$/', $syncKey)) {
    $storageFile = $dataDir . '/' . $syncKey . '.json';
} else {
    $safeHash = hash('sha256', 'dt_pro_v1_' . $syncKey);
    $storageFile = $dataDir . '/workspace_' . substr($safeHash, 0, 32) . '.json';
}

if ($action === 'ping') {
    $ws = loadWorkspace($storageFile);
    $users = loadUsersDb($usersDbFile);
    echo json_encode([
        'ok' => true,
        'status' => 'online',
        'app' => 'Doğrudan Temin Otomasyonu Pro Cloud Sync',
        'serverTime' => gmdate('Y-m-d\TH:i:s\Z'),
        'registryExists' => file_exists($usersDbFile),
        'registryPath' => 'dt_sync_storage/users_registry.json',
        'storageWritable' => is_writable($dataDir),
        'userCount' => count($users),
        'hasData' => file_exists($storageFile),
        'projectCount' => count($ws['projects']),
        'updatedAt' => $ws['updatedAt']
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'pull') {
    $ws = loadWorkspace($storageFile);
    echo json_encode([
        'ok' => true,
        'projects' => $ws['projects'],
        'customInstitutions' => $ws['customInstitutions'],
        'deletedIds' => $ws['deletedIds'],
        'updatedAt' => $ws['updatedAt'],
        'projectCount' => count($ws['projects'])
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'push') {
    $incomingProjects = isset($body['projects']) && is_array($body['projects']) ? $body['projects'] : [];
    $incomingInstitutions = isset($body['customInstitutions']) && is_array($body['customInstitutions']) ? $body['customInstitutions'] : [];
    $incomingDeletedIds = isset($body['deletedIds']) && is_array($body['deletedIds']) ? $body['deletedIds'] : [];

    $newWs = [
        'projects' => $incomingProjects,
        'customInstitutions' => $incomingInstitutions,
        'deletedIds' => array_values(array_unique($incomingDeletedIds)),
        'updatedAt' => gmdate('Y-m-d\TH:i:s\Z')
    ];

    $saved = saveWorkspace($storageFile, $newWs);
    if ($saved === false) {
        http_response_code(500);
        echo json_encode(['ok' => false, 'error' => 'Sunucu yazma izni hatası.'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    echo json_encode([
        'ok' => true,
        'projects' => $saved['projects'],
        'customInstitutions' => $saved['customInstitutions'],
        'deletedIds' => $saved['deletedIds'],
        'updatedAt' => $saved['updatedAt'],
        'projectCount' => count($saved['projects'])
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'smart_sync') {
    $clientProjects = isset($body['projects']) && is_array($body['projects']) ? $body['projects'] : [];
    $clientInstitutions = isset($body['customInstitutions']) && is_array($body['customInstitutions']) ? $body['customInstitutions'] : [];
    $clientDeletedIds = isset($body['deletedIds']) && is_array($body['deletedIds']) ? $body['deletedIds'] : [];

    $saved = performSmartMerge($storageFile, $clientProjects, $clientInstitutions, $clientDeletedIds);
    if ($saved === false) {
        http_response_code(500);
        echo json_encode(['ok' => false, 'error' => 'Sunucu yazma izni hatası.'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    echo json_encode([
        'ok' => true,
        'projects' => $saved['projects'],
        'customInstitutions' => $saved['customInstitutions'],
        'deletedIds' => $saved['deletedIds'],
        'updatedAt' => $saved['updatedAt'],
        'projectCount' => count($saved['projects'])
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

http_response_code(400);
echo json_encode(['ok' => false, 'error' => 'Geçersiz işlem (action).'], JSON_UNESCAPED_UNICODE);
